module.exports = require('./eslintrc.json')
