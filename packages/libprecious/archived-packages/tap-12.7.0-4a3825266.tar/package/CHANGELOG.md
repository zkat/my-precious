Please see [the tap website](http://www.node-tap.org/changelog/) for
the curated changelog.
