'use strict';

module.exports = {
  headerPattern: /^(\w*):\s*(.*)$/,
  headerCorrespondence: [
    `tag`,
    `message`
  ]
};
