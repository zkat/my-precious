#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [jscs](https://github.com/jscs-dev/node-jscs) preset


[npm-image]: https://badge.fury.io/js/conventional-changelog-jscs.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-jscs
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-jscs.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-jscs
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-jscs.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-jscs
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-jscs/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-jscs
