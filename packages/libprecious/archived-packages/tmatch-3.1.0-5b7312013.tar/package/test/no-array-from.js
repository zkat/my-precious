'use strict'
Array.from = null
require('./deep.js')
