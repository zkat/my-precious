'use strict'

module.exports = {
  mergePattern: /^Merge pull request #(.*) from .*$/,
  mergeCorrespondence: [`pr`],
  headerPattern: /^\[(.*) (.*)] (.*)$/,
  headerCorrespondence: [
    `tag`,
    `taggedAs`,
    `message`
  ]
}
