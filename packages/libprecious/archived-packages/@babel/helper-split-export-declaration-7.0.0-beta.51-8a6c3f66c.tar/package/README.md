# @babel/helper-split-export-declaration

> 

See our website [@babel/helper-split-export-declaration](https://new.babeljs.io/docs/en/next/babel-helper-split-export-declaration.html) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-split-export-declaration
```

or using yarn:

```sh
yarn add --save @babel/helper-split-export-declaration
```
