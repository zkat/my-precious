# @babel/helper-get-function-arity

> Helper function to get function arity

See our website [@babel/helper-get-function-arity](https://new.babeljs.io/docs/en/next/babel-helper-get-function-arity.html) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-get-function-arity
```

or using yarn:

```sh
yarn add --save @babel/helper-get-function-arity
```
