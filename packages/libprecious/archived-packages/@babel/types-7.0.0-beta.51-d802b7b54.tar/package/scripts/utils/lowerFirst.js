"use strict";
module.exports = function lowerFirst(string) {
  return string[0].toLowerCase() + string.slice(1);
};
