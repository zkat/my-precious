'use strict';

var regex = /^(?:\r\n|\n|\r)+|(?:\r\n|\n|\r)+$/g;

module.exports = function (str) {
	return str.replace(regex, '');
};
