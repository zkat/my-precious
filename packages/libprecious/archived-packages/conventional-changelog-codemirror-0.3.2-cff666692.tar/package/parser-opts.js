'use strict';

module.exports = {
  headerPattern: /^\[(.*?)(?: (.*))?] (.*)$/,
  headerCorrespondence: [
    `language`,
    `type`,
    `message`
  ]
};
