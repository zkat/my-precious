# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.0"></a>
# 1.0.0 (2016-06-06)


### Features

* initial code ([08074cd](https://github.com/nexdrew/which-module/commit/08074cd))
