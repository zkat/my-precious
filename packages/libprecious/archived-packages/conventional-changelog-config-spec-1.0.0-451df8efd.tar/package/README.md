# Conventional Changelog Configuration Spec

## Versions

- [v1.0.0](versions/1.0.0/README.md) - *Current*