/**
 * Generates version README.md files based on JSON Schema(s).
 */
const path = require('path')
const fs = require('fs')

const VERSIONS_PATH = path.resolve(__dirname, '../versions')
const versions = fs.readdirSync(VERSIONS_PATH)
/**
 * Iterate through the available versions, creating `README.md`s where possible.
 */
versions.forEach((version) => {
  const location = path.resolve(VERSIONS_PATH, version, 'schema.json')
  const exists = fs.existsSync(location)
  if (!exists) {
    console.log(`Unable to location JSON Schema file (schema.json) for version: ${version}.`)
  } else {
    console.log(`Generating documentation for version: ${version}`)
  }
  /**
   * Load the JSON Schema for the version and generate the README.md
   */
  const schema = require(location)
  const readme = generateREADMEfromSchema({
    version,
    schema
  })

  console.log(readme)
})
/**
 * Converts a JSON Schema spec object to a string (Markdown) for
 * writing to disk as a README.
 */
function generateREADMEfromSchema ({ version, schema }) {
  let markdown = `# Conventional Changelog Configuration Spec (v${version})`

  markdown += `\n${schema.description}`

  markdown += `\n## Structure`

  const documentation = {
    structure: [],
    substitutions: {}
  }
  for (const property in schema.properties) {
    const spec = schema.properties[property]
    markdown += generateTableOfContentsItemFromProperty(property, spec);
    documentation.structure.push([
      `\n### ${property} (\`${spec.type}\`)`,
      spec.description,
      '#### Default',
      '```js\n'+JSON.stringify(spec.default, null, 2)+'\n```'
    ].join('\n'));
  }

  markdown += `\n## Substitutions`

  markdown += `\n---`

  markdown += documentation.structure.join('\n');

  return markdown
}

function generateTableOfContentsItemFromProperty(name, spec, toc = '') {
  toc += `\n- [${name}](#${name}-${spec.type})`
  if (spec.properties || spec.items) {
    const children = spec.properties || spec.items;

    console.log(children);

    toc = children.reduce((acc, p, s) => {
      return generateTableOfContentsItemFromProperty(p, s, acc);
    }, '\n  ');
  }
  return toc;
}