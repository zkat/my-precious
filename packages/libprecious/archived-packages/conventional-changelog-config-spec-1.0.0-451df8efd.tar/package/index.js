module.exports = require('./versions/1.0.0/schema.json')
