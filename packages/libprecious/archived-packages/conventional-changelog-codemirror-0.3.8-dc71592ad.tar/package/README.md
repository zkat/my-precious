#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [CodeMirror](https://github.com/codemirror/codemirror) preset


[npm-image]: https://badge.fury.io/js/conventional-changelog-codemirror.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-codemirror
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-codemirror.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-codemirror
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-codemirror.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-codemirror
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-codemirror/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-codemirror
