# fs-exists-cached

Just like `fs.exists` and `fs.existsSync`, but cached
