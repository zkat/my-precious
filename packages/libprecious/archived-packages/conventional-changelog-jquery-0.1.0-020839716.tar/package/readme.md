#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [jQuery](https://github.com/jquery/jquery) preset


See [convention](convention.md)


[npm-image]: https://badge.fury.io/js/conventional-changelog-jquery.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-jquery
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-jquery.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-jquery
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-jquery.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-jquery
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-jquery/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-jquery
