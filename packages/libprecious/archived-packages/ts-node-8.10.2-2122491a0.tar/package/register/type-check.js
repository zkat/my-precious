require('../').register({
  typeCheck: true
})
