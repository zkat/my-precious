require('../dist').register({
  files: true
})
