'use strict';

module.exports = {
  headerPattern: /^(\w*)\: (.*)$/,
  headerCorrespondence: [
    'component',
    'shortDesc'
  ]
};
