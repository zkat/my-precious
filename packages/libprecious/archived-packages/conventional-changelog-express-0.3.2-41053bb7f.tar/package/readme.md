#  [![NPM version][npm-image]][npm-url] [![Build Status][travis-image]][travis-url] [![Dependency Status][daviddm-image]][daviddm-url] [![Coverage Status][coveralls-image]][coveralls-url]

> [conventional-changelog](https://github.com/ajoslin/conventional-changelog) [express](https://github.com/strongloop/express) preset

**Issues with the convention itself should be reported on the Express issue tracker.**

[npm-image]: https://badge.fury.io/js/conventional-changelog-express.svg
[npm-url]: https://npmjs.org/package/conventional-changelog-express
[travis-image]: https://travis-ci.org/stevemao/conventional-changelog-express.svg?branch=master
[travis-url]: https://travis-ci.org/stevemao/conventional-changelog-express
[daviddm-image]: https://david-dm.org/stevemao/conventional-changelog-express.svg?theme=shields.io
[daviddm-url]: https://david-dm.org/stevemao/conventional-changelog-express
[coveralls-image]: https://coveralls.io/repos/stevemao/conventional-changelog-express/badge.svg
[coveralls-url]: https://coveralls.io/r/stevemao/conventional-changelog-express
