'use strict'
module.exports = require('./tacks.js')
module.exports.generateFromDir = require('./generate-from-dir.js')
