'use strict';

module.exports = {
  headerPattern: /^\[\[(.*)]] (.*)$/,
  headerCorrespondence: [
    `type`,
    `shortDesc`
  ],
  noteKeywords: `BREAKING CHANGE`
};
