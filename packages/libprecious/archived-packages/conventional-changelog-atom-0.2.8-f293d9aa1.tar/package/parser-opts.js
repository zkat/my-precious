'use strict'

module.exports = {
  headerPattern: /^(:.*?:) (.*)$/,
  headerCorrespondence: [
    `emoji`,
    `shortDesc`
  ]
}
