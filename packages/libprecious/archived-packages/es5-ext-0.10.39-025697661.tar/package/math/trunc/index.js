"use strict";

module.exports = require("./is-implemented")()
	? Math.trunc
	: require("./shim");
