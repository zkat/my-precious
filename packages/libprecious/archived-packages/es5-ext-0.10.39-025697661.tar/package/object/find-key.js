"use strict";

module.exports = require("./_iterate")(require("../array/#/find"), false);
