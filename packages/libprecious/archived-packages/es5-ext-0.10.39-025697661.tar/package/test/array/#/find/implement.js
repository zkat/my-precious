"use strict";

var isImplemented = require("../../../../array/#/find/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
