## 2.1.1

- Remove support for false in error position of callback

## 2.1.0

- Add `no-callback-literal` rule

